"""
Test P0 and P1 features for AITravelglobe:
- City-Level Search
- Calendar Integration (.ics export)
- Itinerary API
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

# Test credentials
TEST_EMAIL = "test7381@example.com"
TEST_PASSWORD = "TestPass123!"


@pytest.fixture(scope="module")
def auth_token():
    """Get authentication token"""
    response = requests.post(
        f"{BASE_URL}/api/auth/login",
        json={"email": TEST_EMAIL, "password": TEST_PASSWORD}
    )
    if response.status_code == 200:
        return response.json().get("access_token")
    pytest.skip("Authentication failed - skipping authenticated tests")


@pytest.fixture
def api_client():
    """Shared requests session"""
    session = requests.Session()
    session.headers.update({"Content-Type": "application/json"})
    return session


@pytest.fixture
def authenticated_client(api_client, auth_token):
    """Session with auth header"""
    api_client.headers.update({"Authorization": f"Bearer {auth_token}"})
    return api_client


class TestHealthCheck:
    """Basic health check tests"""
    
    def test_health_endpoint(self, api_client):
        """Test health endpoint returns 200"""
        response = api_client.get(f"{BASE_URL}/api/health")
        assert response.status_code == 200
        data = response.json()
        assert data.get("status") == "healthy"


class TestAuthentication:
    """Authentication tests"""
    
    def test_login_success(self, api_client):
        """Test login with valid credentials"""
        response = api_client.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": TEST_EMAIL, "password": TEST_PASSWORD}
        )
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "user" in data
        assert data["user"]["email"] == TEST_EMAIL
    
    def test_login_invalid_credentials(self, api_client):
        """Test login with invalid credentials"""
        response = api_client.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": "wrong@example.com", "password": "wrongpass"}
        )
        assert response.status_code in [401, 400]


class TestPlacesAutocomplete:
    """City-Level Search - Places Autocomplete tests"""
    
    def test_autocomplete_france(self, api_client):
        """Test autocomplete returns results for 'France'"""
        response = api_client.get(f"{BASE_URL}/api/places/autocomplete?query=France")
        assert response.status_code == 200
        data = response.json()
        assert "predictions" in data
        assert len(data["predictions"]) > 0
        
        # Check that France-related results are returned
        descriptions = [p["description"] for p in data["predictions"]]
        france_results = [d for d in descriptions if "France" in d]
        assert len(france_results) > 0, "Should return France-related results"
    
    def test_autocomplete_paris(self, api_client):
        """Test autocomplete returns results for 'Paris'"""
        response = api_client.get(f"{BASE_URL}/api/places/autocomplete?query=Paris")
        assert response.status_code == 200
        data = response.json()
        assert "predictions" in data
        assert len(data["predictions"]) > 0
    
    def test_autocomplete_empty_query(self, api_client):
        """Test autocomplete with empty query"""
        response = api_client.get(f"{BASE_URL}/api/places/autocomplete?query=")
        # Should return 200 with empty predictions or 400
        assert response.status_code in [200, 400]


class TestItineraryAPI:
    """Itinerary API tests"""
    
    def test_get_itinerary_requires_auth(self, api_client):
        """Test that getting itinerary requires authentication"""
        response = api_client.get(f"{BASE_URL}/api/itinerary/test-id")
        assert response.status_code == 401
    
    def test_get_itineraries_list(self, authenticated_client):
        """Test getting list of itineraries"""
        response = authenticated_client.get(f"{BASE_URL}/api/itineraries")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)


class TestCalendarIntegration:
    """Calendar Integration (.ics export) tests"""
    
    @pytest.fixture
    def test_itinerary_id(self, authenticated_client):
        """Create a test itinerary and return its ID"""
        # First check if we have any existing itineraries
        response = authenticated_client.get(f"{BASE_URL}/api/itineraries")
        if response.status_code == 200:
            itineraries = response.json()
            if itineraries:
                return itineraries[0]["id"]
        
        # If no itineraries, create one
        response = authenticated_client.post(
            f"{BASE_URL}/api/itinerary/generate",
            json={
                "destination": "London, UK",
                "start_date": "2026-04-01",
                "end_date": "2026-04-02",
                "trip_type": "solo",
                "interests": ["Cultural Sites"],
                "budget_range": "medium",
                "travelers_count": 1,
                "has_children": False,
                "children_ages": [],
                "special_requirements": "",
                "include_nearby_cities": False,
                "is_business_trip": False
            },
            timeout=180
        )
        if response.status_code == 200:
            return response.json()["id"]
        pytest.skip("Could not create test itinerary")
    
    def test_calendar_endpoint_requires_auth(self, api_client):
        """Test that calendar endpoint requires authentication"""
        response = api_client.get(f"{BASE_URL}/api/itinerary/test-id/calendar.ics")
        assert response.status_code == 401
    
    def test_calendar_endpoint_returns_ics(self, authenticated_client, test_itinerary_id):
        """Test that calendar endpoint returns valid ICS file"""
        response = authenticated_client.get(
            f"{BASE_URL}/api/itinerary/{test_itinerary_id}/calendar.ics"
        )
        assert response.status_code == 200
        
        # Check content type
        content_type = response.headers.get("content-type", "")
        assert "text/calendar" in content_type or "application/octet-stream" in content_type
        
        # Check ICS content
        content = response.text
        assert "BEGIN:VCALENDAR" in content
        assert "VERSION:2.0" in content
        assert "END:VCALENDAR" in content
        assert "BEGIN:VEVENT" in content
        assert "END:VEVENT" in content
    
    def test_calendar_endpoint_invalid_id(self, authenticated_client):
        """Test calendar endpoint with invalid itinerary ID"""
        response = authenticated_client.get(
            f"{BASE_URL}/api/itinerary/invalid-id-12345/calendar.ics"
        )
        assert response.status_code in [404, 500]


class TestItineraryGeneration:
    """Itinerary generation tests"""
    
    def test_generate_itinerary_requires_auth(self, api_client):
        """Test that itinerary generation requires authentication"""
        response = api_client.post(
            f"{BASE_URL}/api/itinerary/generate",
            json={
                "destination": "Tokyo, Japan",
                "start_date": "2026-05-01",
                "end_date": "2026-05-02",
                "trip_type": "solo"
            }
        )
        assert response.status_code == 401
    
    def test_generate_itinerary_with_nearby_cities(self, authenticated_client):
        """Test itinerary generation with include_nearby_cities flag"""
        response = authenticated_client.post(
            f"{BASE_URL}/api/itinerary/generate",
            json={
                "destination": "Rome, Italy",
                "start_date": "2026-06-01",
                "end_date": "2026-06-02",
                "trip_type": "solo",
                "interests": ["Cultural Sites"],
                "budget_range": "medium",
                "travelers_count": 1,
                "has_children": False,
                "children_ages": [],
                "special_requirements": "",
                "include_nearby_cities": True,
                "is_business_trip": False
            },
            timeout=180
        )
        # Should return 200 with itinerary data
        assert response.status_code == 200
        data = response.json()
        assert "id" in data
        assert "destination" in data
        assert "days" in data
