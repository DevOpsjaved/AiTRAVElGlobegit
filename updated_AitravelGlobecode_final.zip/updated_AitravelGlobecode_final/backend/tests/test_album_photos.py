"""
Test Album Photo Upload and Visibility Bug Fix
Tests the fix for uploaded photos not being visible in albums.
The fix changed static file mount from /uploads to /api/uploads for proper Kubernetes ingress routing.
"""
import pytest
import requests
import os
import io
from PIL import Image

BASE_URL = "https://globetrotter-app-6.preview.emergentagent.com"

# Test credentials
TEST_EMAIL = "albumtest@test.com"
TEST_PASSWORD = "Test123!"
EXISTING_ALBUM_ID = "fb4ea7b8-24e3-42bd-a32b-6264e3c82e02"


class TestAlbumPhotoFix:
    """Test album photo upload and visibility after the /api/uploads fix"""
    
    @pytest.fixture(scope="class")
    def auth_token(self):
        """Get authentication token for test user"""
        response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": TEST_EMAIL, "password": TEST_PASSWORD}
        )
        if response.status_code == 200:
            return response.json().get("access_token")
        pytest.skip(f"Authentication failed: {response.status_code} - {response.text}")
    
    @pytest.fixture(scope="class")
    def auth_headers(self, auth_token):
        """Get headers with auth token"""
        return {"Authorization": f"Bearer {auth_token}"}
    
    def test_01_login_success(self):
        """Test that test user can login"""
        response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": TEST_EMAIL, "password": TEST_PASSWORD}
        )
        assert response.status_code == 200, f"Login failed: {response.text}"
        data = response.json()
        assert "access_token" in data, "No access_token in response"
        assert "user" in data, "No user in response"
        print(f"Login successful for {TEST_EMAIL}")
    
    def test_02_get_albums_list(self, auth_headers):
        """Test fetching albums list"""
        response = requests.get(
            f"{BASE_URL}/api/albums",
            headers=auth_headers
        )
        assert response.status_code == 200, f"Failed to get albums: {response.text}"
        albums = response.json()
        assert isinstance(albums, list), "Albums should be a list"
        print(f"Found {len(albums)} albums")
        
        # Check if existing album is present
        album_ids = [a.get('id') for a in albums]
        if EXISTING_ALBUM_ID in album_ids:
            print(f"Existing test album found: {EXISTING_ALBUM_ID}")
    
    def test_03_get_existing_album_details(self, auth_headers):
        """Test fetching existing album details"""
        response = requests.get(
            f"{BASE_URL}/api/albums/{EXISTING_ALBUM_ID}",
            headers=auth_headers
        )
        
        if response.status_code == 404:
            pytest.skip("Existing test album not found - may have been deleted")
        
        assert response.status_code == 200, f"Failed to get album: {response.text}"
        album = response.json()
        
        assert album.get('id') == EXISTING_ALBUM_ID, "Album ID mismatch"
        print(f"Album name: {album.get('name')}")
        print(f"Album has {len(album.get('media', []))} media items")
        
        # Check media URLs use /api/uploads prefix
        for media in album.get('media', []):
            url = media.get('url', '')
            assert url.startswith('/api/uploads/'), f"Media URL should start with /api/uploads/, got: {url}"
            print(f"Media URL verified: {url}")
    
    def test_04_create_new_album(self, auth_headers):
        """Test creating a new album"""
        album_name = "TEST_Photo_Upload_Test_Album"
        response = requests.post(
            f"{BASE_URL}/api/albums",
            headers={**auth_headers, "Content-Type": "application/json"},
            json={"name": album_name, "description": "Testing photo upload fix"}
        )
        assert response.status_code == 200, f"Failed to create album: {response.text}"
        album = response.json()
        
        assert album.get('name') == album_name, "Album name mismatch"
        assert 'id' in album, "Album should have an ID"
        print(f"Created album: {album.get('id')}")
        
        # Store album ID for cleanup
        return album.get('id')
    
    def test_05_upload_photo_to_album(self, auth_headers):
        """Test uploading a photo to an album and verify URL format"""
        # First create a test album
        create_response = requests.post(
            f"{BASE_URL}/api/albums",
            headers={**auth_headers, "Content-Type": "application/json"},
            json={"name": "TEST_Upload_Test", "description": "For upload testing"}
        )
        assert create_response.status_code == 200, f"Failed to create album: {create_response.text}"
        album_id = create_response.json().get('id')
        
        # Create a test image in memory
        img = Image.new('RGB', (100, 100), color='blue')
        img_bytes = io.BytesIO()
        img.save(img_bytes, format='PNG')
        img_bytes.seek(0)
        
        # Upload the image
        files = {'file': ('test_image.png', img_bytes, 'image/png')}
        data = {'caption': 'Test upload', 'capture_date': '2025-01-22'}
        
        upload_response = requests.post(
            f"{BASE_URL}/api/albums/{album_id}/media",
            headers=auth_headers,
            files=files,
            data=data
        )
        
        assert upload_response.status_code == 200, f"Failed to upload: {upload_response.text}"
        media = upload_response.json()
        
        # CRITICAL: Verify URL uses /api/uploads prefix (the bug fix)
        url = media.get('url', '')
        assert url.startswith('/api/uploads/'), f"Media URL should start with /api/uploads/, got: {url}"
        assert media.get('media_type') == 'image', "Media type should be image"
        print(f"Uploaded media URL: {url}")
        
        # Verify the image is accessible
        full_url = f"{BASE_URL}{url}"
        img_response = requests.get(full_url)
        assert img_response.status_code == 200, f"Image not accessible at {full_url}: {img_response.status_code}"
        
        # Verify content type is image
        content_type = img_response.headers.get('content-type', '')
        assert 'image' in content_type, f"Expected image content-type, got: {content_type}"
        print(f"Image accessible at {full_url} with content-type: {content_type}")
        
        # Cleanup - delete the test album
        requests.delete(f"{BASE_URL}/api/albums/{album_id}", headers=auth_headers)
        print("Test album cleaned up")
    
    def test_06_verify_album_cover_image_set(self, auth_headers):
        """Test that first uploaded image sets as album cover"""
        # Create album
        create_response = requests.post(
            f"{BASE_URL}/api/albums",
            headers={**auth_headers, "Content-Type": "application/json"},
            json={"name": "TEST_Cover_Test", "description": "For cover image testing"}
        )
        album_id = create_response.json().get('id')
        
        # Upload first image
        img = Image.new('RGB', (100, 100), color='green')
        img_bytes = io.BytesIO()
        img.save(img_bytes, format='PNG')
        img_bytes.seek(0)
        
        files = {'file': ('cover_test.png', img_bytes, 'image/png')}
        upload_response = requests.post(
            f"{BASE_URL}/api/albums/{album_id}/media",
            headers=auth_headers,
            files=files
        )
        assert upload_response.status_code == 200
        
        # Get album and verify cover image is set
        album_response = requests.get(f"{BASE_URL}/api/albums/{album_id}", headers=auth_headers)
        album = album_response.json()
        
        cover_image = album.get('cover_image')
        assert cover_image is not None, "Cover image should be set after first upload"
        assert cover_image.startswith('/api/uploads/'), f"Cover image URL should start with /api/uploads/, got: {cover_image}"
        print(f"Cover image set correctly: {cover_image}")
        
        # Cleanup
        requests.delete(f"{BASE_URL}/api/albums/{album_id}", headers=auth_headers)
    
    def test_07_delete_media_from_album(self, auth_headers):
        """Test deleting media from an album - SKIPPED: Backend endpoint missing"""
        # NOTE: The DELETE /api/albums/{album_id}/media/{media_id} endpoint is not implemented
        # Frontend expects this endpoint but backend doesn't have it
        # This is a separate issue from the photo visibility bug fix
        pytest.skip("DELETE /api/albums/{album_id}/media/{media_id} endpoint not implemented in backend")
    
    def test_08_static_file_mount_path(self):
        """Test that /api/uploads path serves files correctly (not HTML)"""
        # This tests the core fix - /api/uploads should serve static files, not React HTML
        
        # First login and upload a test image
        login_response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": TEST_EMAIL, "password": TEST_PASSWORD}
        )
        token = login_response.json().get("access_token")
        headers = {"Authorization": f"Bearer {token}"}
        
        # Create album
        create_response = requests.post(
            f"{BASE_URL}/api/albums",
            headers={**headers, "Content-Type": "application/json"},
            json={"name": "TEST_Static_Mount_Test", "description": "Testing static mount"}
        )
        album_id = create_response.json().get('id')
        
        # Upload image
        img = Image.new('RGB', (50, 50), color='purple')
        img_bytes = io.BytesIO()
        img.save(img_bytes, format='PNG')
        img_bytes.seek(0)
        
        files = {'file': ('static_test.png', img_bytes, 'image/png')}
        upload_response = requests.post(
            f"{BASE_URL}/api/albums/{album_id}/media",
            headers=headers,
            files=files
        )
        media_url = upload_response.json().get('url')
        
        # CRITICAL TEST: Fetch the image and verify it's NOT HTML
        full_url = f"{BASE_URL}{media_url}"
        img_response = requests.get(full_url)
        
        assert img_response.status_code == 200, f"Image request failed: {img_response.status_code}"
        
        content_type = img_response.headers.get('content-type', '')
        # The bug was that /uploads returned HTML (text/html) instead of image
        assert 'text/html' not in content_type, f"Got HTML instead of image! Content-type: {content_type}"
        assert 'image' in content_type, f"Expected image content-type, got: {content_type}"
        
        # Verify content is actually image data (PNG magic bytes)
        content = img_response.content
        assert content[:8] == b'\x89PNG\r\n\x1a\n', "Response is not valid PNG data"
        
        print(f"Static file mount working correctly - {full_url} returns image/png")
        
        # Cleanup
        requests.delete(f"{BASE_URL}/api/albums/{album_id}", headers=headers)
    
    def test_09_album_item_count(self, auth_headers):
        """Test that album listing shows correct item counts"""
        # Create album with multiple images
        create_response = requests.post(
            f"{BASE_URL}/api/albums",
            headers={**auth_headers, "Content-Type": "application/json"},
            json={"name": "TEST_Count_Test", "description": "Testing item count"}
        )
        album_id = create_response.json().get('id')
        
        # Upload 3 images
        for i, color in enumerate(['red', 'green', 'blue']):
            img = Image.new('RGB', (50, 50), color=color)
            img_bytes = io.BytesIO()
            img.save(img_bytes, format='PNG')
            img_bytes.seek(0)
            
            files = {'file': (f'count_test_{i}.png', img_bytes, 'image/png')}
            requests.post(
                f"{BASE_URL}/api/albums/{album_id}/media",
                headers=auth_headers,
                files=files
            )
        
        # Get albums list and verify count
        albums_response = requests.get(f"{BASE_URL}/api/albums", headers=auth_headers)
        albums = albums_response.json()
        
        test_album = next((a for a in albums if a.get('id') == album_id), None)
        assert test_album is not None, "Test album not found in list"
        
        media_count = len(test_album.get('media', []))
        assert media_count == 3, f"Expected 3 media items, got {media_count}"
        print(f"Album shows correct item count: {media_count}")
        
        # Cleanup
        requests.delete(f"{BASE_URL}/api/albums/{album_id}", headers=auth_headers)


class TestCleanup:
    """Cleanup test data"""
    
    def test_cleanup_test_albums(self):
        """Delete all TEST_ prefixed albums"""
        login_response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": TEST_EMAIL, "password": TEST_PASSWORD}
        )
        if login_response.status_code != 200:
            pytest.skip("Cannot login for cleanup")
        
        token = login_response.json().get("access_token")
        headers = {"Authorization": f"Bearer {token}"}
        
        albums_response = requests.get(f"{BASE_URL}/api/albums", headers=headers)
        albums = albums_response.json()
        
        deleted_count = 0
        for album in albums:
            if album.get('name', '').startswith('TEST_'):
                requests.delete(f"{BASE_URL}/api/albums/{album.get('id')}", headers=headers)
                deleted_count += 1
        
        print(f"Cleaned up {deleted_count} test albums")
