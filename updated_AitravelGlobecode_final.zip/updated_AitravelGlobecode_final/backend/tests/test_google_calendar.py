"""
Test Google Calendar Integration Endpoints
- GET /api/auth/google-calendar/status - returns connected: false for new users
- GET /api/auth/google-calendar/connect - returns 501 when credentials not configured
- DELETE /api/auth/google-calendar/disconnect - disconnects calendar
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL').rstrip('/')

# Test credentials
TEST_EMAIL = "test7381@example.com"
TEST_PASSWORD = "TestPass123!"


class TestGoogleCalendarIntegration:
    """Test Google Calendar OAuth endpoints"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Login and get auth token"""
        response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": TEST_EMAIL,
            "password": TEST_PASSWORD
        })
        assert response.status_code == 200, f"Login failed: {response.text}"
        self.token = response.json().get("access_token")
        self.headers = {"Authorization": f"Bearer {self.token}"}
    
    def test_calendar_status_returns_connected_false_for_new_user(self):
        """GET /api/auth/google-calendar/status should return connected: false for users without calendar connected"""
        response = requests.get(
            f"{BASE_URL}/api/auth/google-calendar/status",
            headers=self.headers
        )
        
        assert response.status_code == 200, f"Status check failed: {response.text}"
        data = response.json()
        
        # Verify response structure
        assert "connected" in data, "Response should have 'connected' field"
        assert data["connected"] == False, "New user should have connected: false"
        assert "message" in data, "Response should have 'message' field"
        print(f"Calendar status response: {data}")
    
    def test_calendar_connect_returns_501_when_not_configured(self):
        """GET /api/auth/google-calendar/connect should return 501 when GOOGLE_CALENDAR credentials not configured"""
        response = requests.get(
            f"{BASE_URL}/api/auth/google-calendar/connect",
            headers=self.headers
        )
        
        # Since GOOGLE_CALENDAR_CLIENT_ID and GOOGLE_CALENDAR_CLIENT_SECRET are not set separately,
        # it will use the regular GOOGLE_CLIENT_ID which IS configured
        # So it should either return 501 (not configured) or 200 with authorization_url
        
        if response.status_code == 501:
            # Expected when credentials not configured
            data = response.json()
            assert "detail" in data, "501 response should have detail message"
            assert "not configured" in data["detail"].lower() or "admin" in data["detail"].lower()
            print(f"Connect endpoint returned 501 as expected: {data['detail']}")
        elif response.status_code == 200:
            # If GOOGLE_CLIENT_ID is being used as fallback
            data = response.json()
            assert "authorization_url" in data, "200 response should have authorization_url"
            print(f"Connect endpoint returned authorization URL (using fallback credentials)")
        else:
            pytest.fail(f"Unexpected status code: {response.status_code}, response: {response.text}")
    
    def test_calendar_disconnect_works(self):
        """DELETE /api/auth/google-calendar/disconnect should work even if not connected"""
        response = requests.delete(
            f"{BASE_URL}/api/auth/google-calendar/disconnect",
            headers=self.headers
        )
        
        assert response.status_code == 200, f"Disconnect failed: {response.text}"
        data = response.json()
        assert "message" in data, "Response should have message"
        print(f"Disconnect response: {data}")
    
    def test_calendar_status_requires_auth(self):
        """GET /api/auth/google-calendar/status should require authentication"""
        response = requests.get(f"{BASE_URL}/api/auth/google-calendar/status")
        
        # Should return 401 or 403 without auth
        assert response.status_code in [401, 403], f"Expected 401/403 without auth, got {response.status_code}"
        print("Calendar status correctly requires authentication")
    
    def test_calendar_connect_requires_auth(self):
        """GET /api/auth/google-calendar/connect should require authentication"""
        response = requests.get(f"{BASE_URL}/api/auth/google-calendar/connect")
        
        # Should return 401 or 403 without auth
        assert response.status_code in [401, 403], f"Expected 401/403 without auth, got {response.status_code}"
        print("Calendar connect correctly requires authentication")


class TestItineraryGoogleCalendarSync:
    """Test itinerary Google Calendar sync endpoint"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Login and get auth token"""
        response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": TEST_EMAIL,
            "password": TEST_PASSWORD
        })
        assert response.status_code == 200, f"Login failed: {response.text}"
        self.token = response.json().get("access_token")
        self.headers = {"Authorization": f"Bearer {self.token}"}
    
    def test_sync_to_calendar_requires_connection(self):
        """POST /api/itinerary/{id}/add-to-google-calendar should fail if calendar not connected"""
        # First get an itinerary
        response = requests.get(
            f"{BASE_URL}/api/itineraries",
            headers=self.headers
        )
        
        if response.status_code == 200 and response.json():
            itinerary_id = response.json()[0].get("id")
            
            # Try to sync without calendar connected
            sync_response = requests.post(
                f"{BASE_URL}/api/itinerary/{itinerary_id}/add-to-google-calendar",
                headers=self.headers
            )
            
            # Should fail with 400 (not connected) or 501 (not configured)
            assert sync_response.status_code in [400, 501], f"Expected 400/501, got {sync_response.status_code}"
            print(f"Sync correctly fails when calendar not connected: {sync_response.json()}")
        else:
            pytest.skip("No itineraries found to test sync")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
