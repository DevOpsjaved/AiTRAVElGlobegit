"""
P2 Features Test Suite
- Drive-Based Album Storage (local file system)
- Alternative Location Suggestions
- Trip Photos button integration
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

# Test credentials
TEST_EMAIL = "test7381@example.com"
TEST_PASSWORD = "TestPass123!"


class TestAuthentication:
    """Authentication tests"""
    
    @pytest.fixture(scope="class")
    def auth_token(self):
        """Get authentication token"""
        response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": TEST_EMAIL, "password": TEST_PASSWORD}
        )
        assert response.status_code == 200, f"Login failed: {response.text}"
        data = response.json()
        assert "access_token" in data
        return data["access_token"]
    
    def test_login_success(self):
        """Test login with valid credentials"""
        response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": TEST_EMAIL, "password": TEST_PASSWORD}
        )
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "user" in data
        assert data["user"]["email"] == TEST_EMAIL


class TestAlternativePlaces:
    """Test Alternative Places API - P2 Feature"""
    
    def test_alternatives_restaurant_paris(self):
        """Test finding alternative restaurants in Paris"""
        response = requests.get(
            f"{BASE_URL}/api/places/alternatives",
            params={
                "place_name": "Restaurant",
                "location": "Paris",
                "place_type": "restaurant"
            }
        )
        assert response.status_code == 200
        data = response.json()
        
        # Verify response structure
        assert "alternatives" in data
        assert "original_place" in data
        assert "location" in data
        assert "place_type" in data
        assert "count" in data
        
        # Verify we get alternatives
        assert data["count"] >= 1, "Should return at least 1 alternative"
        assert len(data["alternatives"]) >= 1
        
        # Verify alternative structure
        alt = data["alternatives"][0]
        assert "name" in alt
        assert "address" in alt
        assert "rating" in alt
        assert "maps_url" in alt
        assert "place_id" in alt
    
    def test_alternatives_hotel_london(self):
        """Test finding alternative hotels in London"""
        response = requests.get(
            f"{BASE_URL}/api/places/alternatives",
            params={
                "place_name": "Hotel",
                "location": "London",
                "place_type": "hotel"
            }
        )
        assert response.status_code == 200
        data = response.json()
        
        assert data["place_type"] == "hotel"
        assert data["location"] == "London"
        assert "alternatives" in data
    
    def test_alternatives_cafe_tokyo(self):
        """Test finding alternative cafes in Tokyo"""
        response = requests.get(
            f"{BASE_URL}/api/places/alternatives",
            params={
                "place_name": "Cafe",
                "location": "Tokyo",
                "place_type": "cafe"
            }
        )
        assert response.status_code == 200
        data = response.json()
        
        assert data["place_type"] == "cafe"
        assert "alternatives" in data
    
    def test_alternatives_returns_max_5(self):
        """Test that alternatives returns max 5 results"""
        response = requests.get(
            f"{BASE_URL}/api/places/alternatives",
            params={
                "place_name": "Restaurant",
                "location": "New York",
                "place_type": "restaurant"
            }
        )
        assert response.status_code == 200
        data = response.json()
        
        assert len(data["alternatives"]) <= 5, "Should return max 5 alternatives"
    
    def test_alternatives_has_photos_and_ratings(self):
        """Test that alternatives include photos and ratings"""
        response = requests.get(
            f"{BASE_URL}/api/places/alternatives",
            params={
                "place_name": "Restaurant",
                "location": "Paris",
                "place_type": "restaurant"
            }
        )
        assert response.status_code == 200
        data = response.json()
        
        if data["alternatives"]:
            alt = data["alternatives"][0]
            # Photo may be None if not available
            assert "photo" in alt
            # Rating should be present
            assert "rating" in alt
            # Maps URL should be present
            assert "maps_url" in alt
            assert "google.com/maps" in alt["maps_url"]


class TestTripAlbumIntegration:
    """Test Trip Album Integration - P2 Feature"""
    
    @pytest.fixture(scope="class")
    def auth_token(self):
        """Get authentication token"""
        response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": TEST_EMAIL, "password": TEST_PASSWORD}
        )
        assert response.status_code == 200
        return response.json()["access_token"]
    
    @pytest.fixture(scope="class")
    def auth_headers(self, auth_token):
        """Get auth headers"""
        return {"Authorization": f"Bearer {auth_token}"}
    
    def test_get_user_itineraries(self, auth_headers):
        """Test getting user itineraries"""
        response = requests.get(
            f"{BASE_URL}/api/itineraries",
            headers=auth_headers
        )
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        return data
    
    def test_get_or_create_trip_album(self, auth_headers):
        """Test GET /api/itinerary/{id}/album - creates album if not exists"""
        # First get itineraries
        itin_response = requests.get(
            f"{BASE_URL}/api/itineraries",
            headers=auth_headers
        )
        assert itin_response.status_code == 200
        itineraries = itin_response.json()
        
        if not itineraries:
            pytest.skip("No itineraries found for testing")
        
        itinerary_id = itineraries[0]["id"]
        
        # Get or create album
        response = requests.get(
            f"{BASE_URL}/api/itinerary/{itinerary_id}/album",
            headers=auth_headers
        )
        assert response.status_code == 200
        album = response.json()
        
        # Verify album structure
        assert "id" in album
        assert "name" in album
        assert "user_id" in album
        assert "trip_ids" in album
        assert itinerary_id in album["trip_ids"]
        assert "media" in album
        assert "is_public" in album
        assert "share_token" in album
    
    def test_itinerary_has_album_id_after_creation(self, auth_headers):
        """Test that itinerary has album_id after album is created"""
        # Get itineraries
        itin_response = requests.get(
            f"{BASE_URL}/api/itineraries",
            headers=auth_headers
        )
        itineraries = itin_response.json()
        
        if not itineraries:
            pytest.skip("No itineraries found")
        
        itinerary_id = itineraries[0]["id"]
        
        # First call to create album
        requests.get(
            f"{BASE_URL}/api/itinerary/{itinerary_id}/album",
            headers=auth_headers
        )
        
        # Now get the itinerary and verify album_id
        response = requests.get(
            f"{BASE_URL}/api/itinerary/{itinerary_id}",
            headers=auth_headers
        )
        assert response.status_code == 200
        itinerary = response.json()
        
        assert "album_id" in itinerary
        assert itinerary["album_id"] is not None
    
    def test_album_endpoint_returns_same_album(self, auth_headers):
        """Test that calling album endpoint twice returns same album"""
        # Get itineraries
        itin_response = requests.get(
            f"{BASE_URL}/api/itineraries",
            headers=auth_headers
        )
        itineraries = itin_response.json()
        
        if not itineraries:
            pytest.skip("No itineraries found")
        
        itinerary_id = itineraries[0]["id"]
        
        # First call
        response1 = requests.get(
            f"{BASE_URL}/api/itinerary/{itinerary_id}/album",
            headers=auth_headers
        )
        album1 = response1.json()
        
        # Second call
        response2 = requests.get(
            f"{BASE_URL}/api/itinerary/{itinerary_id}/album",
            headers=auth_headers
        )
        album2 = response2.json()
        
        # Should return same album
        assert album1["id"] == album2["id"]


class TestAlbumsAPI:
    """Test Albums CRUD API"""
    
    @pytest.fixture(scope="class")
    def auth_token(self):
        """Get authentication token"""
        response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": TEST_EMAIL, "password": TEST_PASSWORD}
        )
        assert response.status_code == 200
        return response.json()["access_token"]
    
    @pytest.fixture(scope="class")
    def auth_headers(self, auth_token):
        """Get auth headers"""
        return {"Authorization": f"Bearer {auth_token}"}
    
    def test_get_albums(self, auth_headers):
        """Test getting user albums"""
        response = requests.get(
            f"{BASE_URL}/api/albums",
            headers=auth_headers
        )
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
    
    def test_create_album(self, auth_headers):
        """Test creating a new album"""
        response = requests.post(
            f"{BASE_URL}/api/albums",
            headers=auth_headers,
            json={
                "name": "TEST_P2_Album",
                "description": "Test album for P2 features"
            }
        )
        assert response.status_code == 200
        album = response.json()
        
        assert "id" in album
        assert album["name"] == "TEST_P2_Album"
        assert album["description"] == "Test album for P2 features"
        
        return album["id"]
    
    def test_get_album_by_id(self, auth_headers):
        """Test getting album by ID"""
        # First create an album
        create_response = requests.post(
            f"{BASE_URL}/api/albums",
            headers=auth_headers,
            json={"name": "TEST_GetById_Album"}
        )
        album_id = create_response.json()["id"]
        
        # Get by ID
        response = requests.get(
            f"{BASE_URL}/api/albums/{album_id}",
            headers=auth_headers
        )
        assert response.status_code == 200
        album = response.json()
        assert album["id"] == album_id
        assert album["name"] == "TEST_GetById_Album"
    
    def test_delete_album(self, auth_headers):
        """Test deleting an album"""
        # First create an album
        create_response = requests.post(
            f"{BASE_URL}/api/albums",
            headers=auth_headers,
            json={"name": "TEST_ToDelete_Album"}
        )
        album_id = create_response.json()["id"]
        
        # Delete it
        response = requests.delete(
            f"{BASE_URL}/api/albums/{album_id}",
            headers=auth_headers
        )
        assert response.status_code == 200
        
        # Verify it's deleted
        get_response = requests.get(
            f"{BASE_URL}/api/albums/{album_id}",
            headers=auth_headers
        )
        assert get_response.status_code == 404


class TestHealthCheck:
    """Basic health check tests"""
    
    def test_api_health(self):
        """Test API is responding"""
        response = requests.get(f"{BASE_URL}/api/health")
        assert response.status_code == 200


# Cleanup fixture
@pytest.fixture(scope="session", autouse=True)
def cleanup_test_albums():
    """Cleanup test albums after all tests"""
    yield
    
    # Login
    login_response = requests.post(
        f"{BASE_URL}/api/auth/login",
        json={"email": TEST_EMAIL, "password": TEST_PASSWORD}
    )
    if login_response.status_code != 200:
        return
    
    token = login_response.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    
    # Get all albums
    albums_response = requests.get(f"{BASE_URL}/api/albums", headers=headers)
    if albums_response.status_code != 200:
        return
    
    # Delete test albums
    for album in albums_response.json():
        if album["name"].startswith("TEST_"):
            requests.delete(f"{BASE_URL}/api/albums/{album['id']}", headers=headers)
