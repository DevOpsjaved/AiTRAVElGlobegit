# AITravelglobe iOS App

## Building the iOS App

Since iOS apps require Xcode on macOS, you have two options:

### Option 1: Use PWABuilder Web Interface (Recommended)
1. Go to https://www.pwabuilder.com
2. Enter URL: https://travel-planner-pro-1.preview.emergentagent.com
3. Click "Start"
4. Select "iOS" platform
5. Click "Generate" to download the Xcode project
6. Open the downloaded project in Xcode on a Mac
7. Build and submit to App Store

### Option 2: Manual WKWebView Wrapper
1. Create a new iOS project in Xcode
2. Use WKWebView to load the PWA URL
3. Configure the Info.plist with the values in this folder
4. Add app icons from the icons folder
5. Build and test on simulator/device

### App Configuration
- Bundle ID: com.aitravelglobe.app
- PWA URL: https://travel-planner-pro-1.preview.emergentagent.com
- Theme Color: #d4a853
- Background Color: #ffffff

### Requirements
- macOS with Xcode 15+
- Apple Developer Account for App Store submission
- iOS 15.0+ target
