import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Sparkles, Loader2, RefreshCw, Mic, MicOff, Volume2, VolumeX, Settings } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useTheme } from '../contexts/ThemeContext';
import axios from 'axios';
import { toast } from 'sonner';

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const AIChatBubble = () => {
  const { isLight } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: "Hello! I'm your AI travel companion. Ask me anything about destinations, travel tips, or let me help you plan your perfect trip! You can also use the microphone to speak to me!",
      isWelcome: true
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const [isReconnecting, setIsReconnecting] = useState(false);
  
  // Voice states
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessingVoice, setIsProcessingVoice] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [selectedVoice, setSelectedVoice] = useState('nova');
  const [showSettings, setShowSettings] = useState(false);
  
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const audioRef = useRef(null);

  const voices = [
    { id: 'alloy', name: 'Alloy', description: 'Neutral' },
    { id: 'coral', name: 'Coral', description: 'Warm' },
    { id: 'echo', name: 'Echo', description: 'Calm' },
    { id: 'nova', name: 'Nova', description: 'Upbeat' },
    { id: 'onyx', name: 'Onyx', description: 'Deep' },
    { id: 'shimmer', name: 'Shimmer', description: 'Cheerful' }
  ];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  // Start voice recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        stream.getTracks().forEach(track => track.stop());
        await processVoiceInput(audioBlob);
      };

      mediaRecorder.start();
      setIsRecording(true);
      toast.info('Listening... Tap mic again when done');
    } catch (error) {
      console.error('Microphone access error:', error);
      toast.error('Could not access microphone. Please check permissions.');
    }
  };

  // Stop voice recording
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // Process voice input through backend
  const processVoiceInput = async (audioBlob) => {
    setIsProcessingVoice(true);
    
    try {
      const formData = new FormData();
      formData.append('audio', audioBlob, 'voice.webm');
      formData.append('voice', selectedVoice);
      
      // Add user message placeholder
      setMessages(prev => [...prev, { role: 'user', content: '🎤 Processing voice...', isVoice: true }]);
      
      const response = await axios.post(`${API}/voice/chat`, formData, {
        withCredentials: true,
        headers: { 'Content-Type': 'multipart/form-data' },
        timeout: 60000
      });
      
      // Update user message with transcription
      setMessages(prev => {
        const newMessages = [...prev];
        const lastUserIdx = newMessages.findLastIndex(m => m.role === 'user' && m.isVoice);
        if (lastUserIdx !== -1) {
          newMessages[lastUserIdx] = { role: 'user', content: response.data.user_text, isVoice: true };
        }
        return newMessages;
      });
      
      // Add AI response
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: response.data.ai_text,
        hasAudio: true,
        audioBase64: response.data.audio_base64
      }]);
      
      // Auto-play audio response if voice enabled
      if (voiceEnabled && response.data.audio_base64) {
        playAudio(response.data.audio_base64);
      }
      
    } catch (error) {
      console.error('Voice processing error:', error);
      toast.error('Voice processing failed. Please try again.');
      // Remove placeholder message
      setMessages(prev => prev.filter(m => !(m.isVoice && m.content === '🎤 Processing voice...')));
    } finally {
      setIsProcessingVoice(false);
    }
  };

  // Play audio response
  const playAudio = (base64Audio) => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    
    const audio = new Audio(`data:audio/mp3;base64,${base64Audio}`);
    audioRef.current = audio;
    
    audio.onplay = () => setIsSpeaking(true);
    audio.onended = () => setIsSpeaking(false);
    audio.onerror = () => setIsSpeaking(false);
    
    audio.play().catch(err => {
      console.error('Audio playback error:', err);
      setIsSpeaking(false);
    });
  };

  // Stop audio playback
  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setIsSpeaking(false);
    }
  };

  const sendMessage = async (retryMessage = null, retryCount = 0) => {
    const messageToSend = retryMessage || input;
    if (!messageToSend.trim() || isLoading) return;

    if (!retryMessage) {
      const userMessage = { role: 'user', content: messageToSend };
      setMessages(prev => [...prev, userMessage]);
      setInput('');
    }
    
    setIsLoading(true);

    try {
      const response = await axios.post(`${API}/chat`, {
        message: messageToSend,
        session_id: sessionId
      }, { 
        withCredentials: true,
        timeout: 45000,
        headers: {
          'Content-Type': 'application/json'
        }
      });

      setSessionId(response.data.session_id);
      setIsReconnecting(false);
      
      const aiResponse = {
        role: 'assistant',
        content: response.data.response,
        suggestions: response.data.suggestions
      };
      
      setMessages(prev => prev.filter(m => !m.isReconnecting).concat([aiResponse]));
      
      // Generate TTS for response if voice is enabled
      if (voiceEnabled) {
        generateAndPlayTTS(response.data.response);
      }
      
    } catch (error) {
      console.error('Chat error:', error);
      
      // Only retry once
      if (retryCount < 1 && !isReconnecting) {
        setIsReconnecting(true);
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: "One moment, connecting...",
          isReconnecting: true
        }]);
        
        setTimeout(() => {
          sendMessage(messageToSend, retryCount + 1);
        }, 1000);
        return;
      } else {
        // Provide helpful fallback response
        const fallbackResponses = {
          destination: "Based on popular choices, I'd suggest exploring destinations that match your interests. Paris for culture, Bali for relaxation, or Tokyo for a unique blend of tradition and innovation. Would you like to plan a trip to any of these?",
          plan: "For trip planning, I recommend using our Trip Planner feature - it creates personalized itineraries based on your preferences, dietary needs, and budget. Click 'Plan Trip' in the menu to get started!",
          default: "I'm here to help with your travel plans! I can suggest destinations, recommend restaurants based on your dietary preferences, and help find the best booking options. What would you like to explore?"
        };
        
        let fallback = fallbackResponses.default;
        const lowerMsg = messageToSend.toLowerCase();
        if (lowerMsg.includes('destination') || lowerMsg.includes('where') || lowerMsg.includes('suggest')) {
          fallback = fallbackResponses.destination;
        } else if (lowerMsg.includes('plan') || lowerMsg.includes('itinerary')) {
          fallback = fallbackResponses.plan;
        }
        
        setMessages(prev => prev.filter(m => !m.isReconnecting).concat([{
          role: 'assistant',
          content: fallback,
          suggestions: ["Plan a Trip", "Browse Destinations", "View Profile"]
        }]));
        setIsReconnecting(false);
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Generate TTS for text responses
  const generateAndPlayTTS = async (text) => {
    try {
      const response = await axios.post(`${API}/voice/text-to-speech`, {
        text: text.slice(0, 4096), // Limit to 4096 chars
        voice: selectedVoice
      }, { withCredentials: true });
      
      if (response.data.audio_base64) {
        playAudio(response.data.audio_base64);
      }
    } catch (error) {
      console.error('TTS generation error:', error);
    }
  };

  const handleSuggestionClick = (suggestion) => {
    if (suggestion === "Plan a Trip") {
      window.location.href = '/plan';
    } else if (suggestion === "Browse Destinations") {
      window.location.href = '/';
    } else if (suggestion === "View Profile") {
      window.location.href = '/profile';
    } else {
      setInput(suggestion);
      inputRef.current?.focus();
    }
  };

  const retryLastMessage = () => {
    const lastUserMsg = [...messages].reverse().find(m => m.role === 'user');
    if (lastUserMsg) {
      sendMessage(lastUserMsg.content);
    }
  };

  return (
    <>
      {/* Hidden audio element */}
      <audio ref={audioRef} className="hidden" />
      
      {/* Chat Toggle Button - Premium glassmorphic design */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed z-50 w-14 h-14 sm:w-16 sm:h-16 rounded-full 
                   flex items-center justify-center 
                   transition-all duration-300 
                   right-4 bottom-20 sm:bottom-6
                   ${isOpen ? 'scale-0' : 'scale-100'}
                   group`}
        style={{ 
          background: 'linear-gradient(135deg, #D4AF37 0%, #FCD34D 50%, #D4AF37 100%)',
          boxShadow: '0 8px 32px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255,255,255,0.3)',
          animation: 'pulse-glow 3s ease-in-out infinite'
        }}
        data-testid="chat-toggle"
        aria-label="Open AI Assistant"
      >
        <MessageCircle className="w-6 h-6 sm:w-7 sm:h-7 text-background group-hover:scale-110 transition-transform" />
      </button>

      {/* Chat Window - Premium glass design */}
      <div
        className={`fixed z-50 w-full sm:w-[400px] max-w-full sm:max-w-[calc(100vw-32px)] 
                   sm:rounded-3xl overflow-hidden transition-all duration-300
                   inset-0 sm:inset-auto sm:bottom-6 sm:right-6
                   ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}
        style={{
          background: isLight ? 'rgba(255, 255, 255, 0.98)' : 'rgba(10, 10, 15, 0.95)',
          backdropFilter: 'blur(24px)',
          border: isLight ? '1px solid rgba(0, 0, 0, 0.1)' : '1px solid rgba(255, 255, 255, 0.1)',
          boxShadow: isLight 
            ? '0 25px 50px rgba(0, 0, 0, 0.15), inset 0 1px 0 rgba(255,255,255,0.5)'
            : '0 25px 50px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255,255,255,0.05)'
        }}
        data-testid="chat-window"
      >
        {/* Header */}
        <div className={`p-4 border-b flex items-center justify-between ${isLight ? 'border-gray-200' : 'border-white/10'}`}
             style={{ background: isLight ? 'rgba(249, 250, 251, 0.8)' : 'linear-gradient(180deg, rgba(255,255,255,0.05) 0%, transparent 100%)' }}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl gold-gradient flex items-center justify-center relative
                          shadow-lg shadow-primary/20">
              <Sparkles className="w-5 h-5 text-background" />
              {isReconnecting && (
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-yellow-500 rounded-full animate-pulse" />
              )}
              {isSpeaking && (
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-pulse" />
              )}
            </div>
            <div>
              <h3 className={`font-medium text-sm ${isLight ? 'text-gray-900' : 'text-foreground'}`}>AI Travel Assistant</h3>
              <p className={`text-xs ${isLight ? 'text-gray-500' : 'text-muted-foreground'}`}>
                {isRecording ? '🎤 Listening...' : 
                 isProcessingVoice ? 'Processing voice...' :
                 isSpeaking ? '🔊 Speaking...' :
                 isReconnecting ? 'Reconnecting...' : 'Voice enabled'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setShowSettings(!showSettings)}
              className={`h-8 w-8 ${isLight ? 'hover:bg-gray-100 text-gray-600' : 'hover:bg-white/10'}`}
              title="Voice settings"
            >
              <Settings className="w-4 h-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setVoiceEnabled(!voiceEnabled)}
              className={`h-8 w-8 ${isLight ? 'hover:bg-gray-100 text-gray-600' : 'hover:bg-white/10'}`}
              title={voiceEnabled ? 'Disable voice responses' : 'Enable voice responses'}
            >
              {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsOpen(false)}
              data-testid="chat-close"
              className={`h-8 w-8 ${isLight ? 'hover:bg-gray-100 text-gray-600' : 'hover:bg-white/10'}`}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Voice Settings Panel */}
        {showSettings && (
          <div className={`p-3 border-b ${isLight ? 'border-gray-200 bg-gray-50' : 'border-white/10 bg-white/5'}`}>
            <label className={`text-xs mb-2 block ${isLight ? 'text-gray-500' : 'text-muted-foreground'}`}>Voice</label>
            <Select value={selectedVoice} onValueChange={setSelectedVoice}>
              <SelectTrigger className={`w-full h-9 text-sm ${isLight ? 'bg-white border-gray-200' : 'bg-white/5 border-white/10'}`}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {voices.map(voice => (
                  <SelectItem key={voice.id} value={voice.id}>
                    {voice.name} - {voice.description}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Messages */}
        <ScrollArea className="h-[300px] sm:h-[350px] p-3 sm:p-4" ref={scrollRef}>
          <div className="space-y-3 sm:space-y-4">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                    msg.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : msg.isReconnecting
                        ? 'bg-yellow-500/10 border border-yellow-500/20'
                        : isLight 
                          ? 'bg-gray-100 border border-gray-200' 
                          : 'bg-white/5 border border-white/10'
                  }`}
                >
                  {msg.isReconnecting && (
                    <div className="flex items-center gap-2 text-yellow-500 text-xs mb-2">
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      Reconnecting
                    </div>
                  )}
                  {msg.isVoice && msg.role === 'user' && (
                    <div className="flex items-center gap-1 text-xs opacity-70 mb-1">
                      <Mic className="w-3 h-3" /> Voice
                    </div>
                  )}
                  <p className={`text-sm whitespace-pre-wrap ${msg.role !== 'user' && isLight ? 'text-gray-800' : ''}`}>{msg.content}</p>
                  
                  {/* Play audio button for AI messages with audio */}
                  {msg.hasAudio && msg.audioBase64 && (
                    <button
                      onClick={() => playAudio(msg.audioBase64)}
                      className="mt-2 flex items-center gap-1 text-xs text-primary hover:underline"
                    >
                      <Volume2 className="w-3 h-3" /> Play again
                    </button>
                  )}
                  
                  {msg.suggestions && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {msg.suggestions.map((sug, sidx) => (
                        <button
                          key={sidx}
                          onClick={() => handleSuggestionClick(sug)}
                          className={`text-xs px-3 py-1.5 rounded-full transition-colors ${
                            isLight 
                              ? 'bg-gray-200 hover:bg-gray-300 text-gray-700' 
                              : 'bg-white/10 hover:bg-white/20'
                          }`}
                        >
                          {sug}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {(isLoading || isProcessingVoice) && !isReconnecting && (
              <div className="flex justify-start">
                <div className={`rounded-2xl px-4 py-3 ${isLight ? 'bg-gray-100 border border-gray-200' : 'bg-white/5 border border-white/10'}`}>
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-5 h-5 animate-spin text-primary" />
                    <span className={`text-xs ${isLight ? 'text-gray-500' : 'text-muted-foreground'}`}>
                      {isProcessingVoice ? 'Processing voice...' : 'Thinking...'}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input */}
        <div className={`p-4 border-t ${isLight ? 'border-gray-200' : 'border-white/10'}`}>
          <form 
            onSubmit={(e) => { e.preventDefault(); sendMessage(); }}
            className="flex gap-2"
          >
            {/* Voice Record Button */}
            <Button
              type="button"
              size="icon"
              variant={isRecording ? "destructive" : "outline"}
              className={`rounded-xl shrink-0 ${isRecording ? 'animate-pulse bg-red-500' : isLight ? 'border-gray-300' : ''}`}
              onClick={isRecording ? stopRecording : startRecording}
              disabled={isProcessingVoice || isLoading}
              title={isRecording ? 'Stop recording' : 'Start voice input'}
            >
              {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </Button>
            
            <Input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type or tap mic to speak..."
              className={`flex-1 rounded-xl ${isLight ? 'bg-gray-100 border-gray-200 text-gray-900 placeholder:text-gray-400' : 'bg-white/5 border-white/10'}`}
              data-testid="chat-input"
              disabled={isRecording}
            />
            
            {/* Stop Speaking Button */}
            {isSpeaking && (
              <Button
                type="button"
                size="icon"
                variant="outline"
                className="rounded-xl shrink-0"
                onClick={stopAudio}
                title="Stop speaking"
              >
                <VolumeX className="w-4 h-4" />
              </Button>
            )}
            
            <Button 
              type="submit" 
              size="icon"
              className="rounded-xl gold-gradient"
              disabled={isLoading || !input.trim() || isRecording}
              data-testid="chat-send"
            >
              <Send className="w-4 h-4 text-background" />
            </Button>
          </form>
        </div>
      </div>
    </>
  );
};

export default AIChatBubble;
