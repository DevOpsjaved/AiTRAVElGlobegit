import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Navbar, Footer } from '../components/Layout';
import { Button } from '../components/ui/button';
import { useAuth } from '../contexts/AuthContext';
import { useDynamicBackground } from '../contexts/DynamicBackgroundContext';
import { useTutorial } from '../contexts/TutorialContext';
import { 
  Plane, MapPin, Calendar, Sparkles, ChevronRight, 
  Globe, Shield, Zap, Users, Star, ArrowRight,
  Hotel, Car, Utensils, Mountain, Heart, HelpCircle, Download
} from 'lucide-react';
import axios from 'axios';

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

// Interest-based hero background images
const INTEREST_BACKGROUNDS = {
  adventure: [
    'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1920&q=80', // Mountains
    'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=1920&q=80', // Snowy peaks
    'https://images.unsplash.com/photo-1483728642387-6c3bdd6c93e5?w=1920&q=80', // Alpine
  ],
  romantic: [
    'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=1920&q=80', // Paris
    'https://images.unsplash.com/photo-1515542622106-78bda8ba0e5b?w=1920&q=80', // Santorini
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1920&q=80', // Venice
  ],
  food: [
    'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1920&q=80', // Fine dining
    'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1920&q=80', // Restaurant
    'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1920&q=80', // Street food
  ],
  culture: [
    'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=1920&q=80', // Rome
    'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=1920&q=80', // Kyoto
    'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=1920&q=80', // Taj Mahal
  ],
  nature: [
    'https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=1920&q=80', // Lake
    'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=1920&q=80', // Forest
    'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1920&q=80', // Beach
  ],
  luxury: [
    'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=1920&q=80', // Resort
    'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=1920&q=80', // Pool
    'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=1920&q=80', // Hotel
  ],
  beach: [
    'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1920&q=80', // Maldives
    'https://images.unsplash.com/photo-1519046904884-53103b34b206?w=1920&q=80', // Tropical
    'https://images.unsplash.com/photo-1473116763249-2faaef81ccda?w=1920&q=80', // Paradise
  ],
  default: [
    'https://images.unsplash.com/photo-1600405062005-745191db11fb?w=1920&q=80', // Travel
    'https://images.unsplash.com/photo-1488085061387-422e29b40080?w=1920&q=80', // Airport
    'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1920&q=80', // Wanderlust
  ]
};

const LandingPage = () => {
  const navigate = useNavigate();
  const { user, token } = useAuth();
  const { visuals } = useDynamicBackground();
  const [destinations, setDestinations] = useState([]);
  const [currentBgIndex, setCurrentBgIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [personalizedBackgrounds, setPersonalizedBackgrounds] = useState([]);
  const [backgroundInfo, setBackgroundInfo] = useState(null);
  const [personalization, setPersonalization] = useState(null);

  // Fetch personalized backgrounds for logged-in users
  useEffect(() => {
    if (user && token) {
      const fetchPersonalizedBackgrounds = async () => {
        try {
          const response = await axios.get(`${API}/dashboard/backgrounds`, {
            headers: { Authorization: `Bearer ${token}` }
          });
          if (response.data.backgrounds?.length > 0) {
            setPersonalizedBackgrounds(response.data.backgrounds);
            setPersonalization(response.data.personalization);
          }
        } catch (error) {
          console.error('Failed to fetch personalized backgrounds:', error);
        }
      };
      fetchPersonalizedBackgrounds();
    }
  }, [user, token]);

  // Get backgrounds - personalized if available, otherwise static
  const userBackgrounds = personalizedBackgrounds.length > 0
    ? personalizedBackgrounds.map(bg => bg.url)
    : user?.profile?.travel_interests?.length > 0
      ? INTEREST_BACKGROUNDS[user.profile.travel_interests[0].toLowerCase()] || INTEREST_BACKGROUNDS.default
      : INTEREST_BACKGROUNDS.default;

  // Current background derived from index
  const heroBackground = userBackgrounds[currentBgIndex % userBackgrounds.length];
  
  // Get current background info for display
  useEffect(() => {
    if (personalizedBackgrounds.length > 0) {
      const currentBg = personalizedBackgrounds[currentBgIndex % personalizedBackgrounds.length];
      setBackgroundInfo(currentBg);
    } else {
      setBackgroundInfo(null);
    }
  }, [currentBgIndex, personalizedBackgrounds]);

  // Fetch destinations on mount
  useEffect(() => {
    let isMounted = true;
    const fetchData = async () => {
      try {
        const response = await axios.get(`${API}/destinations/popular`);
        if (isMounted) {
          setDestinations(response.data);
        }
      } catch (error) {
        console.error('Failed to fetch destinations');
      }
    };
    fetchData();
    return () => { isMounted = false; };
  }, []);

  // Cycle through backgrounds every 8 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentBgIndex(prev => (prev + 1) % userBackgrounds.length);
        setIsTransitioning(false);
      }, 500);
    }, 8000);
    
    return () => clearInterval(interval);
  }, [userBackgrounds.length]);

  const features = [
    {
      icon: Sparkles,
      title: "AI-Powered Planning",
      description: "Our intelligent system understands your preferences and creates personalized itineraries that match your travel style."
    },
    {
      icon: Globe,
      title: "Global Coverage",
      description: "Access curated experiences and hidden gems across thousands of destinations worldwide."
    },
    {
      icon: Shield,
      title: "Trusted Bookings",
      description: "Seamlessly connect to world-renowned booking platforms for flights, hotels, and activities."
    },
    {
      icon: Zap,
      title: "Real-Time Intelligence",
      description: "Get live updates, weather alerts, and location-aware suggestions throughout your journey."
    }
  ];

  const tripTypes = [
    { icon: Heart, label: "Romantic", color: "from-rose-500 to-pink-500" },
    { icon: Users, label: "Family", color: "from-blue-500 to-cyan-500" },
    { icon: Mountain, label: "Adventure", color: "from-emerald-500 to-teal-500" },
    { icon: Utensils, label: "Culinary", color: "from-orange-500 to-amber-500" },
    { icon: Hotel, label: "Luxury", color: "from-violet-500 to-purple-500" },
    { icon: Car, label: "Road Trip", color: "from-sky-500 to-blue-500" }
  ];

  // Tutorial CTA sub-component
  const TutorialCTA = () => {
    const { hasSeenTutorial } = useTutorial();
    
    if (hasSeenTutorial) return null;
    
    return (
      <div className="mt-6 fade-in" style={{animationDelay: '0.35s'}}>
        <button 
          onClick={() => navigate('/tutorial')}
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors group"
        >
          <HelpCircle className="w-4 h-4 group-hover:scale-110 transition-transform" />
          <span>New here? Take a quick tour of all features</span>
          <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col overflow-x-hidden" data-testid="landing-page">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative min-h-[100dvh] flex items-center pt-16 sm:pt-20">
        {/* Dynamic Background based on profile interests */}
        <div 
          className="absolute inset-0 bg-cover bg-center transition-opacity duration-500"
          style={{ 
            backgroundImage: `url(${heroBackground})`,
            opacity: isTransitioning ? 0 : 1
          }}
        />
        {/* Gradient overlay - stronger for better text readability */}
        <div 
          className="absolute inset-0"
          style={{
            background: `linear-gradient(to bottom, 
              rgba(0, 0, 0, 0.7) 0%, 
              rgba(0, 0, 0, 0.5) 40%, 
              rgba(0, 0, 0, 0.85) 100%)`
          }}
        />
        {/* Accent color overlay based on theme */}
        <div 
          className="absolute inset-0 mix-blend-overlay opacity-10"
          style={{ backgroundColor: visuals?.colors?.[0] || '#D4AF37' }}
        />
        
        <div className="container-main relative z-10 py-8 sm:py-12">
          <div className="max-w-3xl">
            {/* Personalized greeting for logged-in users */}
            {user && (
              <p className="text-xs sm:text-sm text-primary mb-2 fade-in drop-shadow-lg">
                Welcome back, {user.name?.split(' ')[0] || 'Traveler'}! 
                {personalization?.interests?.length > 0 && (
                  <span className="text-white/70 hidden sm:inline"> • Personalized for your {personalization.interests[0]} interest</span>
                )}
                {personalization?.archetype && (
                  <span className="text-white/70 hidden sm:inline"> • {personalization.archetype.replace('_', ' ')}</span>
                )}
              </p>
            )}
            <p className="text-xs font-mono uppercase tracking-[0.15em] sm:tracking-[0.2em] text-primary mb-4 sm:mb-6 fade-in drop-shadow-lg">
              Your Intelligent Travel Companion
            </p>
            <h1 className="text-3xl sm:text-5xl md:text-7xl font-serif tracking-tight leading-tight sm:leading-none mb-4 sm:mb-6 fade-in text-white drop-shadow-xl" style={{animationDelay: '0.1s', textShadow: '0 4px 12px rgba(0,0,0,0.5)'}}>
              Travel <span className="gold-text">Smarter</span>,<br />
              Experience <span className="italic">More</span>
            </h1>
            <p className="text-base sm:text-lg md:text-xl text-white/80 leading-relaxed mb-6 sm:mb-10 max-w-xl fade-in drop-shadow-lg" style={{animationDelay: '0.2s', textShadow: '0 2px 8px rgba(0,0,0,0.4)'}}>
              Let AI craft your perfect journey. From hidden gems to iconic landmarks, 
              we create personalized itineraries that match your travel dreams.
            </p>
            
            {/* Background location info */}
            {backgroundInfo && (
              <div className="mb-6 fade-in glass px-4 py-2 rounded-xl inline-flex items-center gap-2" style={{animationDelay: '0.25s'}}>
                <MapPin className="w-4 h-4 text-primary" />
                <span className="text-sm">
                  <span className="text-foreground font-medium">{backgroundInfo.title}</span>
                  {backgroundInfo.location && (
                    <span className="text-muted-foreground"> • {backgroundInfo.location.split(',')[0]}</span>
                  )}
                  {backgroundInfo.rating && (
                    <span className="text-yellow-400 ml-2">★ {backgroundInfo.rating}</span>
                  )}
                </span>
              </div>
            )}
            
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 fade-in" style={{animationDelay: '0.3s'}}>
              <Button 
                onClick={() => navigate('/plan')} 
                className="btn-primary text-base sm:text-lg px-6 sm:px-10 py-4 sm:py-6 gap-2 w-full sm:w-auto"
                data-testid="hero-plan-btn"
              >
                Start Planning
                <ArrowRight className="w-5 h-5" />
              </Button>
              <Button 
                variant="outline" 
                className="btn-secondary text-base sm:text-lg px-6 sm:px-8 py-4 sm:py-6 w-full sm:w-auto"
                onClick={() => document.getElementById('features').scrollIntoView({ behavior: 'smooth' })}
                data-testid="hero-learn-btn"
              >
                Learn More
              </Button>
            </div>

            {/* Tutorial CTA for new users */}
            <TutorialCTA />

            {/* Stats */}
            <div className="flex gap-6 sm:gap-8 md:gap-12 mt-10 sm:mt-16 pt-6 sm:pt-8 border-t border-white/20 fade-in" style={{animationDelay: '0.4s'}}>
              <div>
                <p className="text-2xl sm:text-3xl md:text-4xl font-serif gold-text drop-shadow-lg">50K+</p>
                <p className="text-xs sm:text-sm text-white/70 mt-1 drop-shadow">Trips Planned</p>
              </div>
              <div>
                <p className="text-2xl sm:text-3xl md:text-4xl font-serif gold-text drop-shadow-lg">150+</p>
                <p className="text-xs sm:text-sm text-white/70 mt-1 drop-shadow">Destinations</p>
              </div>
              <div>
                <p className="text-2xl sm:text-3xl md:text-4xl font-serif gold-text drop-shadow-lg">4.9</p>
                <p className="text-xs sm:text-sm text-white/70 mt-1 drop-shadow">User Rating</p>
              </div>
            </div>
          </div>
        </div>

        {/* Background indicator dots with info */}
        <div className="absolute bottom-16 sm:bottom-24 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3">
          {/* Personalization badge */}
          {user && personalizedBackgrounds.length > 0 && (
            <div className="px-3 py-1 rounded-full glass text-xs text-primary/80 flex items-center gap-2">
              <Sparkles className="w-3 h-3" />
              Backgrounds personalized for you
            </div>
          )}
          
          {/* Dots */}
          <div className="flex gap-2">
            {userBackgrounds.map((_, idx) => (
              <button 
                key={idx}
                onClick={() => {
                  setIsTransitioning(true);
                  setTimeout(() => {
                    setCurrentBgIndex(idx);
                    setIsTransitioning(false);
                  }, 300);
                }}
                className={`w-2 h-2 rounded-full transition-all duration-300 cursor-pointer hover:bg-primary/70 ${
                  idx === currentBgIndex ? 'bg-primary w-6' : 'bg-white/30'
                }`}
                aria-label={`Background ${idx + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-white/30 flex items-start justify-center p-2">
            <div className="w-1 h-2 bg-white/50 rounded-full" />
          </div>
        </div>
      </section>

      {/* Trip Types */}
      <section className="py-24 relative">
        <div className="container-main">
          <p className="text-xs font-mono uppercase tracking-[0.2em] text-primary mb-4">
            Travel Your Way
          </p>
          <h2 className="text-4xl md:text-5xl font-serif tracking-tight mb-12">
            Every journey, <span className="italic">personalized</span>
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {tripTypes.map((type, idx) => (
              <button
                key={idx}
                onClick={() => navigate('/plan')}
                className="group p-6 rounded-2xl card-feature
                         hover:border-primary/30 transition-all duration-300 hover-lift"
                style={{ animationDelay: `${idx * 0.05}s` }}
                data-testid={`trip-type-${type.label.toLowerCase()}`}
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${type.color} 
                              flex items-center justify-center mb-4 
                              group-hover:scale-110 group-hover:shadow-lg transition-all duration-300`}>
                  <type.icon className="w-6 h-6 text-white" />
                </div>
                <p className="font-medium text-sm group-hover:text-primary transition-colors">{type.label}</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-24 bg-white/[0.02]">
        <div className="container-main">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <p className="text-xs font-mono uppercase tracking-[0.2em] text-primary mb-4">
              Why AITravelglobe
            </p>
            <h2 className="text-4xl md:text-5xl font-serif tracking-tight mb-6">
              Intelligence meets <span className="gold-text">wanderlust</span>
            </h2>
            <p className="text-muted-foreground">
              We combine cutting-edge AI with deep travel expertise to create experiences 
              that feel both magical and effortless.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, idx) => (
              <div 
                key={idx}
                className="group p-8 rounded-3xl card-feature hover-lift"
                style={{ animationDelay: `${idx * 0.1}s` }}
              >
                <div className="w-14 h-14 rounded-2xl gold-gradient flex items-center justify-center mb-6
                              group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/20 transition-all duration-300">
                  <feature.icon className="w-7 h-7 text-background" />
                </div>
                <h3 className="text-xl font-serif mb-3 group-hover:text-primary transition-colors">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Destinations */}
      <section className="py-24">
        <div className="container-main">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-xs font-mono uppercase tracking-[0.2em] text-primary mb-4">
                Popular Destinations
              </p>
              <h2 className="text-4xl md:text-5xl font-serif tracking-tight">
                Where to <span className="italic">next?</span>
              </h2>
            </div>
            <Link 
              to="/plan" 
              className="hidden md:flex items-center gap-2 text-primary hover:gap-3 transition-all"
            >
              Explore All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations.slice(0, 6).map((dest, idx) => (
              <div 
                key={dest.id}
                className="card-destination group cursor-pointer hover-lift"
                onClick={() => navigate('/plan', { state: { destination: dest.name } })}
                data-testid={`destination-${dest.id}`}
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img 
                    src={dest.image} 
                    alt={dest.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <div className="flex items-center gap-2 text-primary text-xs mb-2">
                    <MapPin className="w-3 h-3" />
                    {dest.country}
                  </div>
                  <h3 className="text-2xl font-serif mb-2">{dest.name}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                    {dest.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {dest.best_for?.slice(0, 3).map((tag, tidx) => (
                      <span 
                        key={tidx}
                        className="text-xs px-3 py-1 rounded-full bg-white/10 text-muted-foreground"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 gold-gradient opacity-10" />
        <div className="container-main relative">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-4xl md:text-6xl font-serif tracking-tight mb-6">
              Ready to explore the <span className="gold-text">world</span>?
            </h2>
            <p className="text-lg text-muted-foreground mb-10 max-w-xl mx-auto">
              Start your journey today. Let our AI craft an unforgettable adventure 
              tailored just for you.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                onClick={() => navigate('/plan')}
                className="btn-primary text-lg px-12 py-6 gap-2"
                data-testid="cta-plan-btn"
              >
                Plan Your Adventure
                <Plane className="w-5 h-5" />
              </Button>
              <Button 
                onClick={() => navigate('/download')}
                variant="outline"
                className="btn-secondary text-lg px-8 py-6 gap-2"
                data-testid="cta-download-btn"
              >
                <Download className="w-5 h-5" />
                Get the App
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default LandingPage;
